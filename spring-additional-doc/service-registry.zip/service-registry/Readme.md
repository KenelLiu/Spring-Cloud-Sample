0.使用JDK1.8.333
1.配置了服务注册中心,该服务中心由2个节点组成[server1:8761,server2:8762]
2.application.yml中的server1,server2 为自定义机器域名, 
  需在hosts文件配置下,对应部署【eureka-server】服务机器ip. 
  开发测试机器都为同一台机器,故使用端口区分.
3.由于application.yml配置了不支持ip访问参数【prefer-ip-address: false】，所以需要用域名访问
  若需ip访问,修改其值即可
4.访问http://server1:8761/ 或 http://server2:8762/
  登录名密码分别对应application.yml 里的user.name 和user.password里的值
5.配置了多个注册节点【2个及2个以上】，避免单节点故障。
  微服务注册到服务中心，把多个注册中心节点都写上即可,参考
  application-eureka-client.yml 中serviceUrl的值

6.注册中心也可去掉用户密码验证，去掉pom.xml 即可
  <dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
  </dependency>

7.启动服务server1 使用spring-eureka-server1目录下的application.yml
8.启动服务server2 使用spring-eureka-server2目录下的application.yml

9.正式部署使用同一个编译后的jar包即可,只是启动时配置不一样
  server1配置: 用 spring-eureka-server1目录下的application.yml
  server2配置: 用 spring-eureka-server2目录下的application.yml
